"use client"
import { createContext } from "react"
export const MusicContext = createContext(null);
export const NextContext = createContext(null);